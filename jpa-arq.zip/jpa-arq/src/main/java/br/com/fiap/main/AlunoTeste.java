package br.com.fiap.main;

import br.com.fiap.entity.Aluno;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class AlunoTeste {

    public static void main(String[] args) {

        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("FIAP_PU");
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();

        //Criar um novo Aluno
/*      Aluno aluno = new Aluno();
        aluno.setNome("Aluno");
        aluno.setMatricula("11112");
        aluno.setCpf("436.458.077-14");
        aluno.setDataNascimento(LocalDate.of(1998,4,10));
        aluno.setAtivo(true);
        aluno.setDataCadastro(LocalDateTime.now());
        aluno.setDataAtualizacao(LocalDateTime.now());

        manager.persist(aluno);

        manager.getTransaction().commit();*/

        // Editar Aluno
/*      Aluno aluno = manager.find(Aluno.class, 3L);
        aluno.setNome("Aluno novo");
        aluno.setCpf("111.111.111-11");
        aluno.setMatricula("22222");
        System.out.println(aluno);*/

        // Excluir Aluno
/*        Aluno aluno = manager.find(Aluno.class, 3L);
        System.out.println(aluno);
        manager.remove(aluno);
        if (manager.find(Aluno.class, 3L) == null) {
            System.out.println("Aluno excluído!");
        }
        manager.getTransaction().commit();*/

        Query query = manager.createQuery("SELECT a from Aluno a");
        List<Aluno> result = query.getResultList();
        result.forEach(System.out::println);

        manager.getTransaction().commit();

        managerFactory.close();
        manager.close();
    }
}
